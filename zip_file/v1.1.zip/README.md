# nthu_print_course
This chrome extension for print out the course list in NTHU AIS.
